orders(order_id, customer_id, status, amount, created_at)
