orders(order_id, customer_id, order_date, amount)
