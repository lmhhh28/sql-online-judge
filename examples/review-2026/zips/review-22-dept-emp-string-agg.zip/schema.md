dept_emp(emp_no, dept_no, from_date, to_date)
